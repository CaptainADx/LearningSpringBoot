<h1>This is a support Page</h1>
<h2>Your car ID ${id}</h2>
<h3>Your car will get ready shortly<h3/>